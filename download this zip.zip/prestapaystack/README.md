# prestapaystack
Paystack for Prestashop
>(Compatible with Prestashop 1.6)
